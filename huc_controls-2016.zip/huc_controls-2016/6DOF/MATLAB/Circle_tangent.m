% @brief Circle_tangent
% @author 
% Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
% thereof is to be copied, reproduced or communicated to any person without
% written permission.
clc
close all
theta = 0:.01:360;
R = 15;
x = R*cosd(theta);
y = R*sind(theta);
C = [0 R]; %center point
mcp = (y-C(2))./(x-C(1));
tan_slope = -1./mcp;%slope of tangent line at each (x,y) point
tan_slope_use = tan_slope(1:1000:end);
theta_use = theta(1:1000:end);
x_use = x(1:1000:end);
y_use = y(1:1000:end);
xt1 = x_use-1;
xt2 = x_use+1;
yt1 = tan_slope_use.*(xt1-x_use)+y_use;
yt2 = tan_slope_use.*(xt2-x_use)+y_use;
figure
plot(x,y,'r');
hold on
axis([min(x)-1 max(x)+1 min(y)-1 max(y)+1])
axis square
% plot([xt1', xt2'],[yt1', yt2'],'k')
for i= 1:length(xt1)
    plot([xt1(i)', xt2(i)'],[yt1(i)', yt2(i)'],'k')
    pause(.3)
end
figure
plot(theta_use,tan_slope_use)
