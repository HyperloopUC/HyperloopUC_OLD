% @brief solve_intersection
% @author 
% Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
% thereof is to be copied, reproduced or communicated to any person without
% written permission.
clc
%solution to intersection of line and cirlce
syms m x b R
E1 = '(m*x+b)^2 + x^2 - R^2 = 0'
sol1 = solve(E1,x)

E2 = '(m*x+b-R)^2 + x^2 - R^2 = 0'
sol2 = solve(E2,x)