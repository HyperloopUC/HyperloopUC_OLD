% @brief distance_calc
% @author 
% Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
% thereof is to be copied, reproduced or communicated to any person without
% written permission.
function [z0,x_track_t,y_track_t] = distance_calc(x1,y1,x2,y2)
global R w
m = (y2-y1)/(x2-x1);
if ~isinf(m)
    b = y1-m*x1;
    xn1 = (R*m - b*m + (R^2*m^2 + 2*R*b -b^2)^(1/2))/(m^2 +1); %track x1
    yn1 = m*xn1 + b; %track y1
    xn2 = (R*m - b*m - (R^2*m^2 + 2*R*b -b^2)^(1/2))/(m^2 +1); %track x2
    yn2 = m*xn2 + b; %track y2
else
    xn1 = x1; %infinit slope so use x of 1st magnet
    xn2 = x2; %infinit slope so use x of 2nd magnet (same as xn1)
    yn1 = -sqrt(R^2-xn1^2)+R; %first solution for x1
    yn2 = sqrt(R^2-xn1^2)+R; %second solution for x1
end

L1 = sqrt((xn1-x1)^2+(yn1-y1)^2);
L2 = sqrt((xn2-x1)^2+(yn2-y1)^2);
[L,ind] = min([L1,L2]);
z0 = L-w/2;

if ind == 1
    x_track_t = xn1;
    y_track_t = yn1;
else
    x_track_t = xn2;
    y_track_t = yn2;
end
end