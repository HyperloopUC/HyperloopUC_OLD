% @brief braking_wo_hb_GG
% @author 
% Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
% thereof is to be copied, reproduced or communicated to any person without
% written permission.
clear all;
clc;
m = 292;
g = 9.81;
dist = 4224;    %feet

%%Accl phase

i = 1;
dt = 0.001;
t(1, 1) = 0;
x(1, 1) = 0;
a(1, 1) = 0;
v(1, 1) = 0;

f1 = figure(1); %displacement
f2 = figure(2); %velocity
f3 = figure(3); %acceleration

while x(i, 1) < 243  %accl distance off 800ft where we have no control
    set(0, 'CurrentFigure', f1);
    plot(t(i, 1), x(i, 1), '-o');
    hold on;
    set(0, 'CurrentFigure', f2);
    plot(t(i, 1), v(i, 1), '-o');
    hold on;
    set(0, 'CurrentFigure', f3);
    plot(t(i, 1), a(i, 1), '-o');
    hold on;
    a(i + 1, 1) = (2.32 * g * m - 50)/m;        %50N drag on pod through out
    x(i + 1, 1) = x(i, 1) + v(i, 1) * dt + 0.5 * a(i, 1) * dt^2;   %s = ut + 1/2at^2
    v(i + 1, 1) = v(i, 1) + a(i + 1, 1) * dt;   % v = u + at
    t(i + 1, 1) = t(i, 1) + dt;
    i = i + 1;
end

% % 0.5 inch away from Al
% c1 = 0.03712121;
% c2 = -8.24697;
% c3 = 807.6667;

% 0.25 inch away from Al
c1 = 0.2207763;
c2 = -43.29531;
c3 = 3568.671;

pushVmax = v(i, 1);
pushTime = t(i, 1);

while v(i,1) > 0
    set(0, 'CurrentFigure', f1);
    plot(t(i, 1), x(i, 1), '-o');
    hold on;
    set(0, 'CurrentFigure', f2);
    plot(t(i, 1), v(i, 1), '-o');
    hold on;
    set(0, 'CurrentFigure', f3);
    plot(t(i, 1), a(i, 1), '-o');
    hold on;
    
    x(i + 1, 1) = x(i, 1) + v(i, 1) * dt + 0.5 * a(i, 1) * dt^2;   %s = ut + 1/2at^2
    
    if v(i, 1) < 30
        a(i + 1, 1) = -(((c1 * v(i, 1)^2 + c2 * v(i, 1) + c3)/m) + 2000.0/m);   % mx.. (ax.^2 + bx. + c)u = 0
    else
        a(i + 1, 1) = -(c1 * v(i, 1)^2 + c2 * v(i, 1) + c3)/m;
    end
    
    v(i + 1, 1) = v(i, 1) + a(i + 1, 1) * dt;   %v = u + at
    t(i + 1, 1) = t(i, 1) + dt;
    
    i = i + 1;
end
hold off;
figure(1), xlabel('time (s)'); ylabel('displacement (m)'); grid on;
figure(2), xlabel('time (s)'); ylabel('velocity (m/s)'); grid on;
figure(3), xlabel('time (s)'); ylabel('acceleration (m/s2)'); grid on;
disp('Total distance travelled')
dist = x(i - 1, 1) * 3.28084

figure(4)
ax = zeros(3,1);
for i = 1:3
    ax(i)=subplot(3,1,i);
end

for i = 1:3
    figure(i)
    h = get(gcf,'Children');
    newh = copyobj(h,4)
    for j = 1:length(newh)
        posnewh = get(newh(j),'Position');
        possub  = get(ax(i),'Position');
        set(newh(j),'Position',...
        [posnewh(1) possub(2) posnewh(3) possub(4)])
    end
    delete(ax(i));
end
figure(4)