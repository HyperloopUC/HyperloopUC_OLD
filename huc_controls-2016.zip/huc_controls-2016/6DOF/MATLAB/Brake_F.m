% @brief Brake_F
% @author 
% Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
% thereof is to be copied, reproduced or communicated to any person without
% written permission.

function [F_l,F_d] = Brake_F(z0,v)
mu0 = 4*pi*1e-7; %relative permeability in H/m
p = 16.39; %magnetic dipole moment expressed in Nm/T or J/T
%The value of magnetic dipole moment is subject to change
c = 0.313*0.0254; %thickness of the beam in m
mu = 1.000022; %relative permeability of Al
sigma=38e6; %conductivity of Al (S/m)
w = 2/(c*mu*mu0*sigma); %mirror velocity, relates to skin depth
K = (3*mu0*p^2*w)/(32*pi*z0^4);
term = 1 - (1./sqrt(1+(v/w)^2));
const = K/v;
F_d = const*term;
F_l = (v/w)*F_d;
end