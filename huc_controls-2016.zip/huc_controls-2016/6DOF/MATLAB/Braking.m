% @brief Braking
% @author 
% Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
% thereof is to be copied, reproduced or communicated to any person without
% written permission.
clc;
clear all;
close all;
mu0=4*pi*1e-7; %relative permeability in H/m
%p=1:10;
p=16.39; %magnetic dipole moment expressed in Nm/T or J/T 
%The value of magnetic dipole moment is subject to change
c=0.313*0.0254; %thickness of the beam in m
mu=1.000022; %relative permeability of Al
sigma=38e6; %conductivity of Al (S/m)
w=2/(c*mu*mu0*sigma); %mirror velocity, relates to skin depth
%z0=0.001:0.001:0.1; %distance from I-beam in m
z0=0.0126;
K=(3*mu0*p^2*w)./(32*pi*z0.^4);
%v=linspace(1,100,numel(z0)); %velocity in m/s
%v=99.77; % velocity of pod in m/s
v=0:.0001:100;
term=1-(1./sqrt(1+(v/w).^2));
const=K./v;
F_d=const.*term;
F_l=(v/w).*F_d;
% 
% plot(z0,F_d)
% % %figure,plot(v,F_d)
%xlabel('Distance between I Beam and Magnet in meters')
%ylabel('Force of attraction in Newtons')
%title('Force vs. Distance')
plot(v,F_d,v,F_l)
xlabel('Velocity in m/s')
ylabel('Drag Force of attraction in Newtons')
title('Force vs. Velocity')
legend('Drag Force','Force')
hold off