% @brief HB_mag_fric_air
% @author 
% Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
% thereof is to be copied, reproduced or communicated to any person without
% written permission.
clear all
clc;

m = 250;
pushAccl = 2.4;
g = 9.81;
travel = 1287;

% 1000 ft pusher phase
pusherDist = 305;
cruiseDist = 61;

% 800 ft pusher phase
% pusherDist = 243;
% cruiseDist = 610;

%%Hoverboard Lift drag model
h_test = [10,12.5,15];
for i = 1:1:18
   Hset(i,1:3) =  h_test;
end

v_test = [0,5,10,15,20,25,30,35,40,45,50,55,60,65,80,90,100,105]';
Vset = [v_test, v_test, v_test];

l10 = [0 78.48 156.96 215.82 274.68 333.54 372.78 402.21 431.64 451.26 461.07 470.88 480.69 489.5 493.12 498.12 510.12 510.12]'/1.25;
l125 = [0 68.67 137.34 196.2 245.25 294.3 323.73 353.16 372.78 392.4 402.21 412.02 421.83 431.64 437.45 441.45 435.64 425.83]'/1.25;
l15 = [0 49.05 88.29 127.53 166.77 196.2 215.82 235.44 255.06 264.87 274.68 284.49 294.3 299.205 301.11 303.51 306.51 306.51]'/1.25;
L_test = [l10, l125, l15];

hq = 10:0.1:15;
vq = 0:1:105;
[HqL, VqL] = meshgrid(hq, vq);

%surface fit between lift, velo and height
LqL = interp2(Hset, Vset, L_test, HqL, VqL,'spline');

%make process faster by selecting points here
LqH = abs(LqL - 306.56);
for i = 1:1:51
    [Vrow(i,1), Hcol(i,1)] = find(LqH(:,i) == min(LqH(:,i)));
end
%generating lift vector
for i = 1:1:51
   LH(i,1) = LqL(Vrow(i,1),i);
end
%generating corresponding velo vector
for i = 1:1:51
   VH(i,1) = Vrow(i,1)-1;
end
%corresponding levitation height
HH = hq';

% formula for generating different heights for different velo
% %HqH = griddata(LH, VH, HH, 306.56, velo,'v4')

d10 = [0 93.195 164.808 172.656 170.694 162.846 158.922 149.112 147.15 137.34 133.416 131.454 129.492 127.53 126.549 125.568 124.587 124.587]';
d125 = [0 68.67 123.606 131.454 127.53 123.606 117.72 115.758 109.872 105.948 103.986 101.043 100.062 99.081 98.1 97.119 96.138 96.138]';
d15 = [0 49.05 96.138 102.024 100.062 96.138 94.176 90.252 86.328 84.366 82.404 80.442 78.48 78.48 77.499 77.499 76.518 76.518]';
D_test = [d10; d125; d15];

for i = 1:1:3
    for j = 1:1:18
        HsetLD(j + (i - 1)*18,1) = h_test(1,i);
    end
end
VsetLD = [v_test; v_test; v_test];
L_test = [l10; l125; l15];
HBLift = fit([HsetLD, VsetLD],L_test,'poly22');
hblc = coeffvalues(HBLift);
multiVarLift = @(hh, vel) (hblc(1,1) - HBLift(10,0)...
                            + hblc(1,2)*hh + hblc(1,3)*vel ...
                            + hblc(1,4)*hh*hh + hblc(1,5)*hh*vel...
                            + hblc(1,6)*vel*vel);
% vel = 0;
% lift = @(hh) multiVarLift(hh, vel);
% hh = fzero(lift,10)
% figure(1)
% plot(HBLift,[H,V],L)

HBDrag = fit([HsetLD, VsetLD],D_test,'poly24');
hbdc = coeffvalues(HBDrag);
multiVarDrag = @(hh, vel) hbdc(1,1) - HBDrag(10,0)...
                            + hbdc(1,2)*hh + hbdc(1,3)*vel + hbdc(1,4)*hh*hh...
                            + hbdc(1,5)*hh*vel + hbdc(1,6)*vel*vel...
                            + hbdc(1,7)*hh*hh*vel + hbdc(1,8)*hh*vel*vel...
                            + hbdc(1,9)*vel*vel*vel + hbdc(1,10)*hh*hh*vel*vel...
                            + hbdc(1,11)*hh*vel*vel*vel +hbdc(1,12)*vel*vel*vel*vel;
% vel = 0;
% drag = @(hh) multiVarDrag(hh, vel);
% hh = fzero(drag,10)
% figure(2)
% plot(HBDrag,[H,V],D)

clear d10 d125 d15 D_test h_test hbdc HBDrag HBLift hblc Hcol hq HqL HsetLD;
clear i j l10 l125 l15 LqH LqL L_test v_test vq VqL Vrow VsetLD ;


%%Accl phase

i = 1;
dt = 0.001;
t(1, 1) = 0;
x(1, 1) = 0;
a(1, 1) = 0;
v(1, 1) = 0;
h(1, 1) = 10;
liftMag = 0;

% f1 = figure(1); %displacement
% f2 = figure(2); %velocity
% f3 = figure(3); %acceleration
% f4 = figure(4); %lift

while x(i, 1) < pusherDist  %accl distance off 800ft where we have no control
    if liftMag < m*g
        h(i, 1) = 10;
        liftMag = 8*multiVarLift(h(i, 1), v(i, 1));
        friction = m*g - liftMag;
    else
        h(i, 1) = griddata(LH, VH, HH, m*g/8., v(i, 1),'v4');
        if h(i, 1) < 10
            liftMag = 8*multiVarLift(h(i, 1), v(i, 1));
        end
        friction = 0;
    end
    dragMag = 8*multiVarDrag(h(i, 1), v(i, 1));
    airDrag = 0.5*0.009872*1.09*0.63585*(v(i, 1)^2);
    a(i + 1, 1) = (pushAccl*g*m - airDrag - dragMag - friction)/m;
    x(i + 1, 1) = x(i, 1) + v(i, 1) * dt + 0.5 * a(i, 1) * dt^2;   %s = ut + 1/2at^2
    v(i + 1, 1) = v(i, 1) + a(i + 1, 1) * dt;   % v = u + at
    t(i + 1, 1) = t(i, 1) + dt;
    i = i + 1;
end

% % 0.5 inch away from Al
% c1 = 0.03712121;
% c2 = -8.24697;
% c3 = 807.6667;

% 0.25 inch away from Al
c1 = 0.2207763;
c2 = -43.29531;
c3 = 3568.671;

pushVmax = v(i, 1);
pushTime = t(i, 1);
stopDist = x(i, 1);
pointer = i;

while x(i, 1) < pusherDist + cruiseDist  %accl distance off 800ft where we have no control
    if liftMag < m*g
        h(i, 1) = 10;
        liftMag = 8*multiVarLift(h(i, 1), v(i, 1));
        friction = m*g - liftMag;
    else
        h(i, 1) = griddata(LH, VH, HH, m*g/8., v(i, 1),'v4');
        if h(i, 1) < 10
            liftMag = 8*multiVarLift(h(i, 1), v(i, 1));
        end
        friction = 0;
    end
    dragMag = 8*multiVarDrag(h(i, 1), v(i, 1));
    airDrag = 0.5*0.009872*1.09*0.63585*(v(i, 1)^2);
    a(i + 1, 1) = -(airDrag + dragMag + friction)/m;
    x(i + 1, 1) = x(i, 1) + v(i, 1) * dt + 0.5 * a(i, 1) * dt^2;   %s = ut + 1/2at^2
    v(i + 1, 1) = v(i, 1) + a(i + 1, 1) * dt;   % v = u + at
    t(i + 1, 1) = t(i, 1) + dt;
    i = i + 1;
end

while v(i,1) > 0
    if liftMag < m*g
        h(i, 1) = 10;
        liftMag = 8*multiVarLift(h(i, 1), v(i, 1));
        friction = m*g - liftMag;
    else
        h(i, 1) = griddata(LH, VH, HH, m*g/8., v(i, 1),'v4');
        if h(i, 1) < 10
            liftMag = 8*multiVarLift(h(i, 1), v(i, 1));
        end
        friction = 0;
    end
    dragMag = 8*multiVarDrag(h(i, 1), v(i, 1));
    airDrag = 0.5*0.009872*1.09*0.63585*(v(i, 1)^2);
    if v(i, 1) < 30
        a(i + 1, 1) = -((c1 * v(i, 1)^2 + c2 * v(i, 1) + c3)*0.75 + 2300.0 + airDrag + dragMag + friction)/m;   % mx.. (ax.^2 + bx. + c)u = 0
    else
        a(i + 1, 1) = -((c1 * v(i, 1)^2 + c2 * v(i, 1) + c3)*0.75 + airDrag + dragMag + friction)/m;
    end
    x(i + 1, 1) = x(i, 1) + v(i, 1) * dt + 0.5 * a(i, 1) * dt^2;   %s = ut + 1/2at^2
    v(i + 1, 1) = v(i, 1) + a(i + 1, 1) * dt;   %v = u + at
    t(i + 1, 1) = t(i, 1) + dt;
    i = i + 1;
end
h(i, 1) = 10;
stopDist = x(i, 1);
figure(1), plot(t, x); xlabel('time (s)'); ylabel('displacement (m)'); grid on;
figure(2), plot(t, v); xlabel('time (s)'); ylabel('velocity (m/s)'); grid on;
figure(3), plot(t, a); xlabel('time (s)'); ylabel('acceleration (m/s2)'); grid on;
figure(4), plot(t, h); xlabel('time (s)'); ylabel('hover (mm)'); grid on;
