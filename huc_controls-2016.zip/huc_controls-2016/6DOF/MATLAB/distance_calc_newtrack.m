% @brief distance_calc_newtrack
% @author 
% Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
% thereof is to be copied, reproduced or communicated to any person without
% written permission.
function [z0,xtrack_t,ytrack_t] = distance_calc_newtrack(x1,y1,x2,y2,phi)
global R w
m = (y2-y1)/(x2-x1);
b = y1-m*x1;

xn1 = (b+tan(phi)*R-2)/(tan(phi)-m); %track x1
yn1 = m*xn1 + b; %track y1

L = sqrt((xn1-x1)^2+(yn1-y1)^2);
z0 = L-w/2;

xtrack_t = xn1;
ytrack_t = yn1;
end