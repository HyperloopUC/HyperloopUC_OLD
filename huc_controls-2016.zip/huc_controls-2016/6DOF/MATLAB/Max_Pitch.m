% @brief max_pitch
% @author 
% Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
% thereof is to be copied, reproduced or communicated to any person without
% written permission.
clear
close
clc
%%
%%constants
v = 100; %m/s
R = 15; %mile
m = 250; %kg
% m = 327.3; %kg %MAX M FOR PUSHER SUPPORT
g = 9.81; %m/s^2
maxh = 14; %mm
minh = 6; %mm
d = 5; %in distance from cg to pusher (up)
h_cg = 7; %in distance from cg to bottom of vehicle
l = 53.32;% in distance from cg to front hover board
l2 = (l-22.95); %in distance from cg to second front hover board

%% conversions
R = R*1609.34; %m
d = d*25.4; %mm
h_cg = h_cg*25.4; %mm
l = l*25.4; %mm
l2 = l2*25.4; %mm
W = m*g; %N
m_8 = m/8; %kg

%%
normal_a = v^2/R
F_n = normal_a*m
max_theta = asind((maxh-minh)/697.23)
theta = 0.65; %deg
%(FH_1+FH_2)*sin(theta)=Fc %sum of forces in y direction = centripital
%(FH_1+FH_2)*cos(theta)=W %sum of forces in z direction = weight
% theta = atand(F_n/W)



%% moment due to pusher
a_p = 2.4*g; %pusher accleration
M = a_p*m*d/1000; %moment about cg due to pusher (pitch down)
% F_p = M/(l/1000); %force in y direction applied on front pair of hoverboards (due to moment created by pusher)
F_p_each = M/((l + l2)/1000); %force in y direction applied on front 2 pairs hoverboard (due to moment created by pusher)
F_w = W/8; %weight supported by each hoverboard
max_F = F_p_each*2+F_w*4; %maximum force needed to be supported by front 2 pairs (weight and due to pusher moment)
max_F_Hover = g*55*4; %total force by front two hover boards (at nominal conditions)
difference = max_F_Hover-max_F;
fprintf('Max Force by Pusher & Weight = %0.2f \n', max_F)
fprintf('Max Hoverboard Force = %0.2f \n', max_F_Hover)
fprintf('Force difference = %0.2f \n', difference)
if max_F < max_F_Hover
    fprintf('SUFFICIENT LIFT! - G2G\n\n\n\n')
end
%check
M1 = max_F_Hover/2*l;%front
M2 = max_F_Hover/2*l2;%2nd front
Mw1 = (F_w*2)*l;
Mw2 = (F_w*2)*l2;
Mp = M;
fprintf('M1 + M2 = %0.2E N*m \n',M1+M2)
fprintf('Weight + Pusher M = %0.2E N*m\n',Mw1+Mw2+Mp)
if (M1+M2)>(Mw1+Mw2+Mp)
    fprintf('SUFFICIENT LIFT! - G2G\n')
end


