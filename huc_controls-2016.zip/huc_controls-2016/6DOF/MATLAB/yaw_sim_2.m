% @brief yaw_sim_2
% @author 
% Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
% thereof is to be copied, reproduced or communicated to any person without
% written permission.
clear all
close all
clc
global R w

%% Track Properties
%inertial frame:
%origin at pod starting location
%positive x to the right
%positive y up
%positive z verticle (up out of ground)
R = 15;%Radius in miles
w = 0.313; %width of the I-beam (in)
L = 1;%track length in miles
theta_end = L/R;%arc length in rad

%% Unit Conversion
R = R*1609.34; %m
w = w*.0254; %m
L = L*1609.34; %m
theta_end = theta_end*180/pi;%arc length in deg

theta_track = -90:.01:(-90+theta_end);
xt = R*cosd(theta_track);
yt = R*sind(theta_track)+R;

T = 30; %total time = 20 second
dt = 0.001; %time step
t = 0:dt:T;
n = length(t); %number of time steps

%% pod properties
%positive y to the right
%positive x along the body (towards the front of the pod)
%positive z down
Izz = 178.74*3;%MMOI about z (euler conventions) - kg*m^2
m = 250;%mass - kg
magw = 0.5; %in
magw = magw*.0254;

numb_mag = 20;
lx = [53 51 49 47 45 -45 -47 -49 -51 -53;
    53 51 49 47 45 -45 -47 -49 -51 -53];%distance from xcg to magnet location (inches)
lx = lx * 0.0254;% (m)
% ly = 0.007+w/2; %EMERGENCY BRAKING
% ly = 0.01+w/2; %BRAKE %distance from body centerline to magnet location (m)
ly = .02+w/2; %GLIDE %distance of magnets to cg
% ly = .08+w/2; %SHITTY %distance of magnets to cg


%% initialize vectors
%position
x_c = zeros(1,n);
y_c = zeros(1,n);
%velocity
vx = zeros(1,n);
vx(1) = 100; %m/s
vy = zeros(1,n);
%acceleration
a = zeros(1,n);
ax = zeros(1,n);
ay = zeros(1,n);
%theta
psi = zeros(1,n);
psi_dot = zeros(1,n);
psi_Ddot = zeros(1,n);
%initial position of magnets in inertial frame
xFR = zeros(5,n);
yFR = xFR;
xFL = xFR;
yFL = xFR;
xBR = xFR;
yBR = xFR;
xBL = xFR;
yBL = xFR;
xFR(:,1) = x_c(1) + lx(1,1:5).*cosd(psi(1)) + ly*sind(psi(1));
yFR(:,1) = y_c(1) + lx(1,1:5).*sind(psi(1)) - ly*cosd(psi(1));
xBR(:,1) = x_c(1) + lx(1,6:end).*cosd(psi(1)) + ly*sind(psi(1));
yBR(:,1) = y_c(1) + lx(1,6:end).*sind(psi(1)) - ly*cosd(psi(1));
xFL(:,1) = x_c(1) + lx(2,1:5).*cosd(psi(1)) - ly*sind(psi(1));
yFL(:,1) = y_c(1) + lx(2,1:5).*sind(psi(1)) + ly*cosd(psi(1));
xBL(:,1) = x_c(1) + lx(2,6:end).*cosd(psi(1)) - ly*sind(psi(1));
yBL(:,1) = y_c(1) + lx(2,6:end).*sind(psi(1)) + ly*cosd(psi(1));
mag_x = [xFL; xBL; xFR; xBR];
mag_y = [yFL; yBL; yFR; yBR];
xfake_L = x_c(1) - ly*sind(psi(1));
xfake_R = x_c(1) + ly*sind(psi(1));
yfake_L = y_c(1) - ly*cosd(psi(1));
yfake_R = y_c(1) + ly*cosd(psi(1));
fake_x = [xfake_L; xfake_R];
fake_y = [yfake_L; yfake_R];
Fn = zeros(20,n);
Ft = zeros(20,n);
Mz_n = zeros(20,n);
Mz_t = zeros(20,n);
Mz_total = zeros(1,n);
z0 = zeros(1,20);
cg_error = zeros(1,n);
change = 0;
stopped = 0;
maghit = 0;
xtrack_t = zeros(1,n);
ytrack_t = zeros(1,n);
%% Sim
for i = 2:n
    fprintf('Percent Complete: %.2f %% \n',i/n*100);%percentage complete
    %calculate distance of magnet to rail
    v = sqrt(vx(i-1)^2+vy(i-1)^2);
    for g = 1:numb_mag
        if g <= numb_mag/2
            x1 = mag_x(g,i-1);
            y1 = mag_y(g,i-1);
            x2 = mag_x(g+10,i-1);
            y2 = mag_y(g+10,i-1);
            [z0(g),~,~] = distance_calc(x1,y1,x2,y2);
        else
            z0(g) = 2*ly-z0(g-10)-w;
        end
        if z0(g)-magw/2 < 0
            fprintf('magnet hit\n')
            maghit = 1;
        end
        [Rep, Drag] = Brake_F(z0(g),v);
        if g > numb_mag/2
            Fn(g,i) = Rep;%calculate force in normal direction (along positive y)
        else
            Fn(g,i) = -Rep;%calculate force in normal direction (along negative y)
        end
        Ft(g,i) = -Drag;%calculate force in tangential (CURRENTLY in positive x direction, need to find sign of drag after looking at velocity direction)
    end
    %calculate distance from cg to track
    x1 = fake_x(1,i-1);
    y1 = fake_y(1,i-1);
    x2 = fake_x(2,i-1);
    y2 = fake_y(2,i-1);
    [z0_fake,xtrack_t(i),ytrack_t(i)] = distance_calc(x1,y1,x2,y2);
    cg_error(i) = ly-(z0_fake+w/2);
        
    %Calculate moments in the body frame
    Mz_n(1:10,i) = Fn(1:10,i)'.*lx(1,:);
    Mz_n(11:end,i) = Fn(11:end,i)'.*lx(1,:);
    Mz_t(1:10,i) = Ft(1:10,i)*ly;%left side = -Moment
    Mz_t(11:end,i) = Ft(11:end,i)*-ly;%right side = +Moment
    Mz_total(i) = sum(Mz_t(:,i))+sum(Mz_n(:,i));%total moment
    %Calculate moments in inertial frame (negative of body frame
    %convention)
    Mz_total_i(i) = -Mz_total(i); %inertial z is up and body z is down
    
    %Sum forces in normal and tangential direction WRT body frame (positive
    %right for Fn and positive forward for Ft)
    Fn_tot(i) = sum(Fn(:,i));
    Ft_tot(i) = sum(Ft(:,i));
    
    %convert Forces to inertial frame
    Fx_tot_i(i) = real(Fn_tot(i)*sind(psi(i)) + Ft_tot(i)*cosd(psi(i))*sign(vx(i-1)));
    Fy_tot_i(i) = real(-Fn_tot(i)*cosd(psi(i)) + Ft_tot(i)*sind(psi(i))*sign(vy(i-1)));
    
    %calculate acceleration due to forces
    ax(i) = Fx_tot_i(i)/m;
    ay(i) = Fy_tot_i(i)/m;
    %calculate velocity
    vx(i) = vx(i-1) + ax(i)*dt;
    vy(i) = vy(i-1) + ay(i)*dt;
    %calculate cg location
    x_c(i) = x_c(i-1) + vx(i)*dt;
    y_c(i) = y_c(i-1) + vy(i)*dt;
    %calculate angular acceleration
    psi_Ddot(i) = Mz_total_i(i)/Izz;
    %calculate angular rate
    psi_dot(i) = psi_dot(i-1) + psi_Ddot(i)*dt;
    %calculate heading
    psi(i) = psi(i-1) + psi_dot(i)*dt;
    %calculate magnet location
    xFR(:,i) = x_c(i) + lx(1,1:5)'.*cosd(psi(i)) + ly*sind(psi(i));
    yFR(:,i) = y_c(i) + lx(1,1:5)'.*sind(psi(i)) - ly*cosd(psi(i));
    xBR(:,i) = x_c(i) + lx(1,6:end)'.*cosd(psi(i)) + ly*sind(psi(i));
    yBR(:,i) = y_c(i) + lx(1,6:end)'.*sind(psi(i)) - ly*cosd(psi(i));
    xFL(:,i) = x_c(i) + lx(2,1:5)'.*cosd(psi(i)) - ly*sind(psi(i));
    yFL(:,i) = y_c(i) + lx(2,1:5)'.*sind(psi(i)) + ly*cosd(psi(i));
    xBL(:,i) = x_c(i) + lx(2,6:end)'.*cosd(psi(i)) - ly*sind(psi(i));
    yBL(:,i) = y_c(i) + lx(2,6:end)'.*sind(psi(i)) + ly*cosd(psi(i));
    mag_x = [xFL; xBL; xFR; xBR];
    mag_y = [yFL; yBL; yFR; yBR];
    xfake_L = x_c(i) - ly*sind(psi(i));
    xfake_R = x_c(i) + ly*sind(psi(i));
    yfake_L = y_c(i) - ly*cosd(psi(i));
    yfake_R = y_c(i) + ly*cosd(psi(i));
    fake_x(:,i) = [xfake_L; xfake_R];
    fake_y(:,i) = [yfake_L; yfake_R];
    if (sqrt(vx(i)^2+vy(i)^2) < .001) || ((x_c(i) > xt(end)) && (y_c(i) > yt(end))) || maghit == 1
        Fn(:,i+1:end) = [];
        Ft(:,i+1:end) = [];
        Fn_tot(i+1:end) = [];
        Ft_tot(i+1:end) = [];
        Fx_tot_i(i+1:end) = [];
        Fy_tot_i(i+1:end) = [];
        x_c(i+1:end) = [];
        y_c(i+1:end) = [];
        mag_x(:,i+1:end) = [];
        mag_y(:,i+1:end) = [];
        psi(i+1:end) = [];
        psi_dot(i+1:end) = [];
        psi_Ddot(i+1:end) = [];
        vx(i+1:end) = [];
        vy(i+1:end) = [];
        ax(i+1:end) = [];
        ay(i+1:end) = [];
        Mz_total(i+1:end) = [];
        Mz_total_i(i+1:end) = [];
        Mz_t(:,i+1:end) = [];
        Mz_n(:,i+1:end) = [];
        t(i+1:end) = [];
        cg_error(i+1:end) = [];
        ytrack_t(i+1:end) = [];
        xtrack_t(i+1:end) = [];
        break
    end
end
%% calculate heading - track heading at that point in time
track_heading = atan2(ytrack_t,xtrack_t); %in radians
track_heading = track_heading.*180/pi; %in degrees
diff_heading = psi-track_heading;

% l = length(xtrack_t);
% xt_comp = xt(1:l);
% yt_comp = yt(1:l);

%% plot results
close all
%animation
% figure
% title('Pod Location')
% xlabel('x location (m)')
% ylabel('y location (m)')
% theta_track = -90:.01:(-90+theta_end);
% xt = R*cosd(theta_track);
% yt = R*sind(theta_track)+R;
% for i = 1:length(x_c)
%     plot(xt,yt)
%     hold on
%     plot(x_c(i),y_c(i),'r')
%     plot(mag_x(:,i),mag_y(:,i),'ro')
%     axis([min(mag_x(10,i))-1 max(mag_x(1,i))+1 min(mag_y(16,i))-.05 max(mag_y(1,i))+.05])
%     hold off
% %     axis equal
%     pause(.001)
% end

%no animation
figure
hold on
plot(xt,yt)
plot(x_c,y_c,'r')
plot(mag_x,mag_y,'ro','MarkerSize',2)
axis([min(x_c) max(x_c) min(y_c) max(y_c)])
title('Pod Location')
xlabel('x location (m)')
ylabel('y location (m)')

figure
plot(t,cg_error)
grid on
title('CG error vs. time')
xlabel('time (s)')
ylabel('center of gravity distance to track (m)')

figure
plot(t,sqrt(vx.^2+vy.^2))
grid on
title('velocity vs. time')
xlabel('time (s)')
ylabel('velocity (m/s)')

figure
plot(t,sqrt(ax.^2+ay.^2)/9.81,[t(1) t(end)],[2.4 2.4])
grid on
title('acceleration vs. time')
xlabel('time (s)')
ylabel('acceleration (G)')

figure
plot(t,Mz_total_i,[t(1),t(end)],[mean(Mz_total_i),mean(Mz_total_i)])
grid on
title('Yaw Moment vs. time')
xlabel('time (s)')
ylabel('Yaw Moment (Nm)')

figure
plot(t,psi)
title('Heading vs. time')
xlabel('time (s)')
ylabel('Heading (deg)')

figure
plot(t,diff_heading)
title('Heading vs. time')
xlabel('time (s)')
ylabel('Heading (with respect to the track) (deg)')

figure
plot(t,track_heading)

figure
plot(xt,yt,xtrack_t,ytrack_t)
