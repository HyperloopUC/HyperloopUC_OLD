% @brief Branking Magnet experiments Post Processing
% @author Pushkarat
% Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
% thereof is to be copied, reproduced or communicated to any person without
% written permission.
clear all;clc;
%vel in m/s. Force results imported as lbf
%4.44822 is for lbf to newtons
%9by8 for 1.125 inch distance between Al and magnet
vel9by8=[0,7.71,15.42,23.13,30.84,38.55,46.26,53.97,61.68,71.32,77.10,80.95,84.81,88.66,92.52,96.37,100.23,104.08];
rep9by8=4.44822*[0,1.41,2.95,3.77,4.19,4.43,4.66,4.76,4.8,4.85,4.89,4.9,4.94,4.92,4.91,4.93,4.91,4.9];
drag9by8=4.44822*[0,4.63,4.73,3.93,3.15,2.53,2.3,1.94,1.66,1.49,1.32,1.25,1.33,1.66,1.62,1.61,1.47,1.42];
%1by2 for 0.5 inch distance between Al and magnet
vel1by2=[0,7.71,15.42,23.13,30.84,38.55,46.26,55.90,61.68,69.39,77.10,84.81,92.52];
rep1by2 =4.44822*[0,4.96,11.68,16.26,18.49,19.79,21.34,21.85,22.26,22.49,22.21,22.47,22.58];
drag1by2=4.44822*[0,26.37,27.98,24.9,21.49,19.66,18.94,17.43,16.67,15.9,14.5,13.84,13.5];

%*4 is to convert forces at 0.5" to forces at 0.25". *4 is to convert forces at 0.25" to forces at 0.125"
rep1by4=(.5/.25)^2*rep1by2;%during experiments force values seemed to be inversely proportional to the square of the gap between Al and magnets
drag1by4=(.5/.25)^2*drag1by2;

theta1by2=180/pi*atan(rep1by2./drag1by2);   theta9by8=180/pi*atan(rep9by8./drag9by8);
force1by2=sqrt(rep1by2.^2+drag1by2.^2);     force9by8=sqrt(rep9by8.^2+drag9by8.^2);

figure(1);
plot(vel9by8,rep9by8,'b-',vel9by8,drag9by8,'b--',vel1by2,rep1by2,'r-',vel1by2,drag1by2,'r--');
xlabel('velocity (m/s)'); ylabel('repulsion and drag (N)');
legend('Repulsion @ 1.125"','Drag @ 1.125"','Repulsion @ 0.5"','Drag @ 0.5"','Location','Best');

figure(2);hold on;
for i=1:numel(drag9by8)
    plot([0,drag9by8(i)],[0,rep9by8(i)],'b','LineWidth',1);
end
for i=1:numel(drag1by2)
    plot([0,drag1by2(i)],[0,rep1by2(i)],'r','LineWidth',1);
end
hold off;
xlabel('Magnetic drag component (N)');ylabel('Magnetic repulsion component (N)');
title({'Longest line = Max magnetic force','Actuator needs to be along this line to minimize moments on it'});

figure(3);
plot(theta9by8,force9by8,'b.-',theta1by2,force1by2,'r.-');
xlabel('Angle between I beam and force vector (degrees)');ylabel('Magnetic force vector magnitude (N)');
title({'According to this plot actuator should be at around 22^o with the I beam','From the 2 data-sets this angle seems to increase as air gap decreases'});
legend('@ 1.125" air gap','@ 0.5" air gap','Location','Best');

figure(4);
plot(vel1by2(1:11),drag1by2(1:11)./drag9by8(1:11),'b',vel1by2(1:11),rep1by2(1:11)./rep9by8(1:11),'r',vel1by2(1:11),(1.125/0.5)^2*ones(11),'k');
xlabel('velocity (m/s)');ylabel('Ratio between drag & repulsion at different air gaps');
title('Assumption that NewForce/OldForce \propto (OldAirGap/NewAirGap)^2 might be incorrect');
legend('Drag@0.5" / Drag@1.125"','Repulsion@0.5" / Repulsion@1.125"','(1.125 / 0.5)^2','Location','Best');