/*
* @brief class for a window that display instructions
* @author HyperloopUC
* Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
* thereof is to be copied, reproduced or communicated to any person without
* written permission.
**/
package Ground_Station_Package;

import java.awt.BorderLayout;
import java.awt.Font;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JTextPane;
import javax.swing.WindowConstants;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.html.HTMLDocument;

public class HelpWindow extends JDialog {
	HTMLDocument doc = new HTMLDocument();
	
	public HelpWindow(JFrame frame) {
		super(frame);
		this.setTitle("HELP INFORMATION");
		this.setLayout(new BorderLayout(500, 80));
	    this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
	    this.setSize(400, 400);
	    Font font = new Font("Helvetica", Font.PLAIN, 14);
	    
	    JTextPane textPane = new JTextPane(); 
        textPane.setFont(font); 
        SimpleAttributeSet attributeSet = new SimpleAttributeSet(); 
        StyleConstants.setAlignment(attributeSet, StyleConstants.ALIGN_CENTER); 
        textPane.setCharacterAttributes(attributeSet, true); 
        textPane.setEditable(false);
        
        textPane.setText("HELP INFORMATION");
        textPane.setContentType("text/html");
        textPane.setText(String.format(""
        		+ "<html>"
                + "<h2>Help Information - Steps to run the Hyperloop setup</h2>"
                + "<ol>"
                + "<li> Press the Start Communication button to communicate between GCS - RPi and GCS - SpaceX"
                + "<li> Turn on Raspberry Pi & Arduino 6 to calibrate ultrasonic"
                + "<li> Reset Arduinos 1 - 5"
                + "<li> Start PWM"
                + "<li> Press Ready for Launch button"
                + "<li> Press Pod Stop button"
                + "<li> Press Retract button"
                + "<li> Press Stop button"
                + "</ol>"
                + "</html>"
                 ));
        this.add(textPane);
        
	}
	
}
