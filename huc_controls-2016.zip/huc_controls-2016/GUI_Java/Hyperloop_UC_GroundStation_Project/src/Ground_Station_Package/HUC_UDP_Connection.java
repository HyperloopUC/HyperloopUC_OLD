/*
* @brief class to create a UDP connection
* @author HyperloopUC
* Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
* thereof is to be copied, reproduced or communicated to any person without
* written permission.
**/
package Ground_Station_Package;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;

/**
 *
 * @author saurabh
 */
public class HUC_UDP_Connection {

    static private DatagramSocket gcsSocket;
    static private DatagramSocket NAPSocket;
    static byte status = 0x00;
    
    public HUC_UDP_Connection() throws SocketException {
        System.out.println("Listening at port 3000");
        gcsSocket = new DatagramSocket(3000);
        
        NAPSocket = new DatagramSocket();
    }

    public static byte[] receiveFromRpi(int timeout) throws InterruptedException {

        byte[] input = new byte[61];
        try {
            DatagramPacket receivePacket = new DatagramPacket(input, input.length);
            gcsSocket.receive(receivePacket);
            input = receivePacket.getData();
            gcsSocket.setSoTimeout(timeout);

        } catch (SocketTimeoutException ste) {
            System.out.println("Connection lost");
            HUC_GroundStation_GUI.connectionLost();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return input;
    }

    public void sendToRpi(byte[] sendData) {
        try {
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, InetAddress.getByName("192.168.0.12"), 3000);
            gcsSocket.send(sendPacket);
            System.out.println("Ack sent");
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }

    public void sendToSpaceX(byte[] sendData) {
        try {
            byte team_id = 0x0E;
            int acceleration;
            int strip;
            int position;
            int velocity;

            if (sendData[0] != 3) {
                if (sendData[0] != 1) {
                    acceleration = (int) Math.sqrt(Math.pow((((sendData[15] & 0xFF) << 8 | (sendData[16]) & 0xFF) * 100), 2) + Math.pow((((sendData[17] & 0xFF) << 8 | (sendData[18]) & 0xFF) * 100), 2) + Math.pow((((sendData[19] & 0xFF) << 8 | (sendData[20]) & 0xFF) * 100), 2));
                    strip = sendData[2];
                    if (strip >= 1 && strip <= 9) {
                        status = 3;
                    } else if (strip > 9) {
                        status = 5;
                    }
                    position = strip * 3048;
                    velocity = ((sendData[3] & 0xFF) << 8 | (sendData[4]) & 0xFF) * 100;
                } else {
                    acceleration = 0;
                    position = 0;
                    velocity = 0;
                }
                ByteBuffer sendDataInByte = ByteBuffer.allocate(34);
                sendDataInByte.put(team_id);
                sendDataInByte.put(status);
                sendDataInByte.put(ByteBuffer.allocate(4).putInt(acceleration).array());
                sendDataInByte.put(ByteBuffer.allocate(4).putInt(position).array());
                sendDataInByte.put(ByteBuffer.allocate(4).putInt(velocity).array());
                sendDataInByte.put(ByteBuffer.allocate(20).putInt(0).array());
                DatagramPacket sendPacket = new DatagramPacket(sendDataInByte.array(), sendDataInByte.array().length, InetAddress.getByName("192.168.0.1"), 3000);
                
                NAPSocket.send(sendPacket);
            }
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }

    public byte[] listen(int timeout) {
        byte[] input = new byte[61];
        byte[] buf = {0x05, 0x0D, 0x0A};
        try {
            input = receiveFromRpi(timeout);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        //sendToRpi("ack".getBytes());
        sendToRpi(buf);
        sendToSpaceX(input);
        return input;
    }

    public void close() {
        gcsSocket.close();
    }

    static void setStatus(byte input_status) {
        status = input_status;
    }

//    private static int convert(int i) {
//        //return (((i & 0xff000000) >> 24) + ((i & 0xff0000) >> 8) + ((i & 0xff00) << 8) + ((i & 0xff) << 16));
//        int value = 0;
//        if(i < 0)
//            value |= (((i & 0x7f000000) >> 24) | 0x80);
//        else
//            value |= ((i & 0xff000000) >> 24);
//        value |= ((i & 0xff0000) >> 8);
//        value |= ((i & 0xff00) << 8);
//        value |= ((i & 0xff) << 24);
//        System.out.println(Integer.toHexString(value));
//        System.out.println(Integer.toHexString((i & 0xff) << 24));
//        System.out.println(Integer.toHexString((i & 0xff00) << 8));
//        System.out.println(Integer.toHexString((i & 0xff0000) >> 8));
//        System.out.println(Integer.toHexString((i & 0xff000000) >> 24));
//        
//
//
////        
////        
////        System.out.println(Integer.toHexString((i & 0xff000000) >> 24));
////        System.out.println(Integer.toHexString((i & 0xff0000) >> 8));
////        System.out.println(Integer.toHexString((i & 0xff00) << 8));
////        System.out.println(Integer.toHexString((i & 0xff) << 24));
//        
//        
////        value = (((i & 0xff000000) >> 24) | ((i & 0xff0000) >> 8) | ((i & 0xff00) << 8) | ((i & 0xff) << 24));
//        return value;
//    }
//
//    public static void main(String[] args) throws UnknownHostException, IOException {
//
//        //HUC_UDP_Connection huc = new HUC_UDP_Connection();
//        DatagramSocket s = new DatagramSocket();
//        byte team_id = 0x0E;
//        status = 1;
//
//        int acceleration = -5;
//        int velocity = 4660;
//        int position = 4 * 3048;
//
//        ByteBuffer sendDataInByte = ByteBuffer.allocate(34);
//        
//        
//        //acceleration = convert(acceleration);
//        //System.out.println(Integer.toHexString(acceleration));
//        //System.out.println(Integer.SIZE);
//        //osition = convert(position);
//        //velocity = convert(velocity);
//
//        sendDataInByte.put(team_id);
//        sendDataInByte.put(status);
//        sendDataInByte.put(ByteBuffer.allocate(4).putInt(acceleration).array());
//        sendDataInByte.put(ByteBuffer.allocate(4).putInt(position).array());
//        sendDataInByte.put(ByteBuffer.allocate(4).putInt(velocity).array());
//        sendDataInByte.put(ByteBuffer.allocate(20).putInt(0).array());
//        System.out.println(new String(sendDataInByte.array()));
//
//        DatagramPacket sendPacket = new DatagramPacket(sendDataInByte.array(), sendDataInByte.array().length, InetAddress.getByName("192.168.1.3"), 3000);
//        s.send(sendPacket);
//
//    }

}
