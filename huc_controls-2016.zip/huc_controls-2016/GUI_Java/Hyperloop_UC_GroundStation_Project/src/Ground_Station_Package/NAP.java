/*
* @brief class to represent NAP
* @author HyperloopUC
* Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
* thereof is to be copied, reproduced or communicated to any person without
* written permission.
**/
package Ground_Station_Package;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.ByteBuffer;

public class NAP {

	private static DatagramSocket clientSocket;
	
	public static void main(String[] args) {
		try{
			byte[] receiveData = new byte[34];
			clientSocket = new DatagramSocket(4000);
		    
		    // UDP connection with NAP server to receive data
		    while(true){
		    	System.out.println("Inside while loop of NAP");
		    	DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
		    	clientSocket.receive(receivePacket);
		    	byte[] incoming = receivePacket.getData();
                        System.out.println(incoming.length);
                        
		    	int acc = ByteBuffer.wrap(incoming, 2, 4).getInt();
                        System.out.println(acc);
		    	int pos = ByteBuffer.wrap(incoming, 6, 4).getInt();
		    	int vel = ByteBuffer.wrap(incoming, 10, 4).getInt();
//		    	int batVol = ByteBuffer.wrap(incoming, 14, 4).getInt();
//		    	int batCur = ByteBuffer.wrap(incoming, 18, 4).getInt();
//		    	int batTem = ByteBuffer.wrap(incoming, 22, 4).getInt();
//		    	int podTem = ByteBuffer.wrap(incoming, 26, 4).getInt();

		    	// The stripe count is going as signed integer value because the strip number will not be exceeding more than the value a signed integer can take -- need to improvise the code to include this feature required by SpaceX
		    	System.out.println(new String((incoming[0] & 0xFF) + " " + (incoming[1] & 0xFF) + " " + Integer.toHexString(acc) + " " + Integer.toHexString(pos) + " " + Integer.toHexString(vel)));
                                //+ " " + batVol + " " + batCur + " " + batTem + " " + podTem + " " + ByteBuffer.wrap(incoming, 30, 4).getInt()));

		    	System.out.print("Data received from server:" );
		    }
		}
		catch(Exception e){
			clientSocket.close();
			e.printStackTrace();
		}
		System.out.println("SpaceX class ended");
	}
}
