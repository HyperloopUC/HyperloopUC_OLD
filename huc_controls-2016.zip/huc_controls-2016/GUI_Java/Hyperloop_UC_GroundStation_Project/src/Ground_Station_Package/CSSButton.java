/*
* @brief factory class to create and format the buttons on control panel
* @author HyperloopUC
* Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
* thereof is to be copied, reproduced or communicated to any person without
* written permission.
**/
package Ground_Station_Package;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.File;
import java.io.FileInputStream;
import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicButtonUI;

class CSSButton extends BasicButtonUI {

    Color defaultColor;
    Color darkerColor;
    Color foregroundColor;
    private Font Open_Sans_Condensed;

    public CSSButton(Color defaultColor, Color darker) {
        this.defaultColor = defaultColor;
        this.darkerColor = darker;
        this.foregroundColor = Color.white;
        try {
            Open_Sans_Condensed = Font.createFont(Font.TRUETYPE_FONT, new FileInputStream(new File("lib\\Open_Sans_Condensed\\OpenSans-CondLight.ttf")));
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public CSSButton(Color defaultColor, Color darker, Color foregroundColor) {
        this.defaultColor = defaultColor;
        this.darkerColor = darker;
        this.foregroundColor = foregroundColor;
        try {
            Open_Sans_Condensed = Font.createFont(Font.TRUETYPE_FONT, new FileInputStream(new File("lib\\Open_Sans_Condensed\\OpenSans-CondLight.ttf")));
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    @Override
    public void installUI(JComponent c) {
        super.installUI(c);
        AbstractButton button = (AbstractButton) c;
        button.setOpaque(false);
        button.setBorder(new EmptyBorder(5, 15, 5, 15));
    }

    @Override
    public void paint(Graphics g, JComponent c) {
        AbstractButton b = (AbstractButton) c;
        paintBackground(g, b, b.getModel().isPressed());
        super.paint(g, c);
    }

    private void paintBackground(Graphics g, JComponent c, boolean pressed) {
        Dimension size = c.getSize();
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        c.setForeground(foregroundColor);
        c.setBackground(defaultColor);
        c.setFont(Open_Sans_Condensed.deriveFont(Font.PLAIN, 25));
        if (pressed) {
            c.setBackground(darkerColor);
        }
        g.setColor(c.getBackground());
        g.fillRoundRect(0, 0, size.width, size.height, 12, 12);
    }
}
