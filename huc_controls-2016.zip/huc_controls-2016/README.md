
# All the controls and electronics algorithms for HUC

# Directory structures
```
huc_controls
\_ 6DOF_v2
  \_ MATLAB
\_ Arduino
  \_ Arduino Beta Testing
    \_ Actuator_Control
      \_ ActuatorControl_Awasthi
      \_ ActuatorControl_Guarang
      \_ loadcell_frictionactuator
    \_ DistanceSensor4_12-26-2017
    \_ Two_Actuator_Control
  \_ Arduino Code Blocks
    \_ distSensor4
  \_ Arduinos
    \_ Final
    \_ Schematics_Shields
\_ braking
  \_ Actuator Control
  \_ code
\_ GUI_Java
  \_ Hyperloop_UC_GroundStation_Project
\_ Hover Engine Testing MATLAB Codes
\_ NAP
\_ RPi
  \_ Beta_phase
\_ Vacuum Testing
  \_ batteryCellVolt4_temp1_dist1
  \_ libraries
  \_ batteryCellVolt4_temp1_dist1
  \_ batteryCellVolt4_temp1_dist1
  \_ VacuumTesting_CAN_Receive_v1
  \_ VacuumTesting_CAN_Send_v1
  \_ VacuumTesting_CAN_Send_v2
README.md
```

# Header 

This header file should be put at the beginning of every code file

Please put this in a comment block. 
Comment block in Python is `""" whatever """`
Comment block in C and Java is `/* whatnot */`
```
@brief _title_

@author/s _name/s_ 

Subject to the existing rights of third parties, HYPERLOOP UC
is the owner of the copyright in this work and no portion
thereof is to be copied, reproduced or communicated to any person without
written permission.
```
