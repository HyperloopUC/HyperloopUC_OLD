// @brief main code for RPi
// @author 
// Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
// thereof is to be copied, reproduced or communicated to any person without
// written permission.

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <fcntl.h>
#include <signal.h>
#include <stdbool.h>
#include "main.h"

// Macros
#define BAUDRATE B115200
#define ARDUINO1 "/dev/arduino1"
#define ARDUINO6 "/dev/arduino6"

struct termios oldtio; //terminos structure initialization for serial communication
struct sockaddr_in remaddr; //socket structure initialization for UDP socket

// Thread initializations
static pthread_mutex_t serial_ard1_mutex_store = PTHREAD_MUTEX_INITIALIZER;
static mutex_type serial_ard1_mutex = &serial_ard1_mutex_store;

static pthread_mutex_t serial_ard6_mutex_store = PTHREAD_MUTEX_INITIALIZER;
static mutex_type serial_ard6_mutex = &serial_ard6_mutex_store;

static pthread_mutex_t socket_mutex_store = PTHREAD_MUTEX_INITIALIZER;
static mutex_type socket_mutex = &socket_mutex_store;

static int fd_socket; // File descriptor for UDP socket
static int fd_ard6_serial; // File descriptor for Arduino6 serial
static bool socket_wait_flag = TRUE; // Socket waiting flag
static bool state = TRUE; // Variable used to exit all the treads
static bool main_ready = FALSE; // Variable set my serial thread 
static bool socket_ready = FALSE; // Variable set my socket thread
static bool connection_lost = FALSE; // Set to true if there is a connection lost by arduino 
static spacex_status status; // enum for spacex status commands

static ard_serial_data_packet serial_data = {0}; // arduino serial packet data
static char socket_data[3]; // socket acknowledgement data packet 

int main(void)
{
    thread_type thread1,thread2;
    int fd_ard1_serial;  
    int rc;
    struct timeval time1_val, time2_val;
    bool value = TRUE;
    char buf[3] = {0};
    int slen=sizeof(remaddr);

    long mtime, seconds, useconds; 

    /* Initializes GPIO and PWM */
    rc = GPIO_init();
    
    if(rc <  0)
    {
        printf("Error in GPIO initialization\n");
    }
    
    /* create a socket */
    if ((fd_socket=socket(AF_INET, SOCK_DGRAM, 0))==-1)
        printf("socket created\n");

    /* Initialize Socket and bind address */
    rc = Socket_init(fd_socket);
    
    if(rc <  0)
    {
        printf("Error in Socket Initialization\n");
    }

    /* Send spacex status "IDLE" to GCS*/
    usleep(100);
    buf[0] = 0x01;
    status = IDLE;
    buf[1] = status; 
    sendto(fd_socket, buf, 2, 0, (struct sockaddr *)&remaddr, slen); 

    /*Open Serial port*/
    fd_ard1_serial = open(ARDUINO1, O_RDWR | O_NOCTTY ); 
    if (fd_ard1_serial <0) 
    {
        perror(ARDUINO1); 
        return 0; 
    }

    /*Open Serial port*/
    fd_ard6_serial = open(ARDUINO6, O_RDWR | O_NOCTTY ); 
    if (fd_ard6_serial <0) 
    {
        perror(ARDUINO6); 
        return 0; 
    }

    /* Initialize Serial ports */
    Serial_init(fd_ard1_serial);
    
    Serial_init(fd_ard6_serial);
    
    /* Reset Arduinos by sending Low and then High on GPIO_GEN6 */
    digitalWrite(GPIO_GEN6, LOW);
    usleep(100000);
    digitalWrite(GPIO_GEN6, HIGH); 
    
    /* Send spacex status "READY" to GCS*/
    buf[0] = 0x01;
    status = READY;
    buf[1] = status; 
    sendto(fd_socket, buf, 2, 0, (struct sockaddr *)&remaddr, slen); 

    Thread_init(); /* Initialize Thread, semaphores */	

    thread1 = Thread_start(Serial_ard1_Thread, (void *)&fd_ard1_serial);
	
    thread2 = Thread_start(Socket_Thread, NULL);

    /* Initial time for generating PWM */
    gettimeofday(&time1_val, NULL);

    /* receives messages from arduino and send the messages to GSC */
    while(!connection_lost) 
    {
		//if ((rc = Thread_wait_cond(serial_cond, 1)) != 0 )
		//		printf("Error %d waiting for semaphore\n", rc);
        /* Generate PWM for every 1 sec */
        gettimeofday(&time2_val, NULL);
        seconds  = time2_val.tv_sec  - time1_val.tv_sec;
        useconds = time2_val.tv_usec - time1_val.tv_usec;

        mtime = ((seconds) * 1000 + useconds/1000.0);

        if(mtime > 1000)
        {
            gettimeofday(&time1_val, NULL);
            if(value)
            {
                value = FALSE;
                digitalWrite(GPIO_GEN1, HIGH);
            }
            else
            {
                value = TRUE;
                digitalWrite(GPIO_GEN1, LOW);
            }
        }
	
	/* Wait untill data is available from arduino */
        while(!main_ready)
        {
            usleep(100);
            if(connection_lost)
                continue;
        }

        rc = Thread_lock_mutex(serial_ard1_mutex);
    	if (rc != 0)
    		printf("Error %s locking mutex\n", strerror(rc));

#ifdef DEBUG
        printf("health:%02x\n", serial_data.health);
        printf("stripe:%02x\n", serial_data.stripe);
        printf("velocity:%04x\n", serial_data.velocity);
        printf("mag_brakes:%02x\n", serial_data.mag_brake);
        printf("fric_brake:%02x\n", serial_data.fric_brake);
        printf("ard3_act[0]:%02x\n", serial_data.ard3_act_dist[0]);
        printf("ard3_act[1]:%02x\n", serial_data.ard3_act_dist[1]);
        printf("ard3_act[2]:%02x\n", serial_data.ard3_act_dist[2]);
        printf("ard3_act[3]:%02x\n", serial_data.ard3_act_dist[3]);
        printf("ard4_act[0]:%02x\n", serial_data.ard4_act_dist[0]);
        printf("ard4_act[1]:%02x\n", serial_data.ard4_act_dist[1]);
        printf("ard4_act[2]:%02x\n", serial_data.ard4_act_dist[2]);
        printf("ard4_act[3]:%02x\n", serial_data.ard4_act_dist[3]);
        printf("acc[0]:%04x\n", serial_data.acc[0]);
        printf("acc[1]:%04x\n", serial_data.acc[1]);
        printf("acc[2]:%04x\n", serial_data.acc[2]);
        printf("omega[0]:%04x\n", serial_data.omega[0]);
        printf("omega[1]:%04x\n", serial_data.omega[1]);
        printf("omega[2]:%04x\n", serial_data.omega[2]);
        printf("dist[0]:%02x\n", serial_data.dist[0]);
        printf("dist[1]:%02x\n", serial_data.dist[1]);
        printf("dist[2]:%02x\n", serial_data.dist[2]);
        printf("dist[3]:%02x\n", serial_data.dist[3]);
        printf("dist[4]:%02x\n", serial_data.dist[4]);
        printf("dist[5]:%02x\n", serial_data.dist[5]);
        printf("dist[6]:%02x\n", serial_data.dist[6]);
        printf("dist[7]:%02x\n", serial_data.dist[7]);
        printf("temp[0]:%04x\n", serial_data.temp[0]);
        printf("temp[1]:%04x\n", serial_data.temp[1]);
        printf("temp[2]:%04x\n", serial_data.temp[2]);
        printf("temp[3]:%04x\n", serial_data.temp[3]);
        printf("temp[4]:%04x\n", serial_data.temp[4]);
        printf("temp[5]:%04x\n", serial_data.temp[5]);
        printf("temp[6]:%04x\n", serial_data.temp[6]);
        printf("temp[7]:%04x\n", serial_data.temp[7]);
        printf("volt[0]:%02x\n", serial_data.voltage[0]);
        printf("volt[1]:%02x\n", serial_data.voltage[1]);
        printf("volt[2]:%02x\n", serial_data.voltage[2]);
        printf("volt[3]:%02x\n", serial_data.voltage[3]);
        printf("volt[4]:%02x\n", serial_data.voltage[4]);
        printf("volt[5]:%02x\n", serial_data.voltage[5]);
        printf("volt[6]:%02x\n", serial_data.voltage[6]);
        printf("volt[7]:%02x\n", serial_data.voltage[7]);
#endif

#if 0
        if((serial_data.health & 0x1) == 0x00)
        {
            digitalWrite(GPIO_GEN0, LOW);
        }
        
        if((serial_data.health & 0x2) == 0x00)
        {
            digitalWrite(GPIO_GEN3, LOW);
        }
        
        if((serial_data.health & 0x4) == 0x00)
        {
            digitalWrite(GPIO_GEN4, LOW);
        }
        
        if((serial_data.health & 0x8) == 0x00)
        {
            digitalWrite(GPIO_GEN5, LOW);
        }
#endif   
        main_ready = FALSE; // Set main_ready to false and waits for arduino serial data

    	rc = Thread_unlock_mutex(serial_ard1_mutex);
		if (rc != 0)
			printf("Error %s unlocking mutex\n", strerror(rc));
        
        usleep(100);
        
    }

    state = FALSE;
   
    Thread_join(thread1);
    Thread_join(thread2);

    tcsetattr(fd_ard1_serial,TCSANOW,&oldtio);
    //tcsetattr(fd_ard6_serial,TCSANOW,&oldtio);
    close(fd_ard1_serial);
    //close(fd_ard6_serial);
    close(fd_socket);
    
    return 0;
}

int GPIO_init()
{
    //int ret;

    /* Initialize wiringPi GPIO */
    wiringPiSetupGpio();

#if 0    
    /* Set PWM output for a cycle of 1sec, this function creates a thread and consumes around .5% of CPU */
    ret = softPwmCreate (GPIO_GEN0, 1, 10000) ;

    if(ret)
    {
        printf("error\n");
        return -1;
    }

    /* Set PWM pin for ON period of 750ms */
    softPwmWrite (GPIO_GEN0, 5000) ;

#endif

    /* Confifure GPIO output */
    pinMode(GPIO_GEN0, OUTPUT);     
    pinMode(GPIO_GEN1, OUTPUT);     
    pinMode(GPIO_GEN2, OUTPUT);     
    pinMode(GPIO_GEN3, OUTPUT);    
    pinMode(GPIO_GEN4, OUTPUT);    
    pinMode(GPIO_GEN5, OUTPUT);
    pinMode(GPIO_GEN6, OUTPUT);
    
    return 0;
}

int Socket_init(int fd)
{
    struct sockaddr_in myaddr;
    char *server = Strdup(SERVER_ADDR); /* change this to use a different server */
    
    /* bind it to client addresses and pick specified port number */
    memset((char *)&myaddr, 0, sizeof(myaddr));
    myaddr.sin_family = AF_INET;
    myaddr.sin_addr.s_addr = inet_addr(CLIENT_ADDR);
    myaddr.sin_port = htons(PORT);

    if (bind(fd, (struct sockaddr *)&myaddr, sizeof(myaddr)) < 0) 
    {
        perror("bind failed");
        return -1;
    }

    /* now define remaddr, the address to whom we want to send messages
    For convenience, the host address is expressed as a numeric IP address
    that we will convert to a binary format via inet_aton */

    memset((char *) &remaddr, 0, sizeof(remaddr));
    remaddr.sin_family = AF_INET;
    remaddr.sin_port = htons(PORT);

    if (inet_aton(server, &remaddr.sin_addr)==0) 
    {
        fprintf(stderr, "inet_aton() failed\n");
        return -1;
    }
    
    return 0;
}

void Serial_init(int fd)
{
    struct termios newtio;
    
    tcgetattr(fd,&oldtio); /* save current port settings */

    bzero(&newtio, sizeof(newtio)); /* Clear terminos configuration */
    newtio.c_cflag = BAUDRATE | CRTSCTS | CS8 | CLOCAL | CREAD;
    /* IGNPAR  : ignore bytes with parity errors
     ICRNL   : map CR to NL (otherwise a CR input on the other computer
     will not terminate input)
     otherwise make device raw (no other input processing)*/
     //newtio.c_iflag = IGNPAR | ICRNL;
    newtio.c_iflag = IGNPAR;

    /* Raw output. */
    newtio.c_oflag = 0;

     /* ICANON  : enable canonical input disable all echo functionality, and
     don't send signals to calling program */
     //newtio.c_lflag = ICANON;
     newtio.c_lflag = 0;
     
     /* initialize all control characters default values can be found in
     /usr/include/termios.h, 
     and are given in the comments, but we don't need them here */
    newtio.c_cc[VINTR]    = 0;     /* Ctrl-c */ 
    newtio.c_cc[VQUIT]    = 0;     /* Ctrl-\ */
    newtio.c_cc[VERASE]   = 0;     /* del */
    newtio.c_cc[VKILL]    = 0;     /* @ */
    newtio.c_cc[VEOF]     = 4;     /* Ctrl-d */
    newtio.c_cc[VTIME]    = 0;     /* inter-character timer unused */
    newtio.c_cc[VMIN]     = 1;     /* blocking read until 1 character arrives */
    newtio.c_cc[VSWTC]    = 0;     /* '\0' */
    newtio.c_cc[VSTART]   = 0;     /* Ctrl-q */ 
    newtio.c_cc[VSTOP]    = 0;     /* Ctrl-s */
    newtio.c_cc[VSUSP]    = 0;     /* Ctrl-z */
    newtio.c_cc[VEOL]     = 0;     /* '\0' */
    newtio.c_cc[VREPRINT] = 0;     /* Ctrl-r */
    newtio.c_cc[VDISCARD] = 0;     /* Ctrl-u */
    newtio.c_cc[VWERASE]  = 0;     /* Ctrl-w */
    newtio.c_cc[VLNEXT]   = 0;     /* Ctrl-v */
    newtio.c_cc[VEOL2]    = 0;     /* '\0' */
 
    tcflush(fd, TCIFLUSH);
    tcsetattr(fd, TCSANOW, &newtio);
}
 
  
void Thread_init()
{
    pthread_mutexattr_t attr;
    int rc;
  
    pthread_mutexattr_init(&attr);
    pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_ERRORCHECK);
    
    if ((rc = pthread_mutex_init(serial_ard1_mutex, &attr)) != 0)
        printf("error %d initializing serial_ard1_mutex\n", rc);
    if ((rc = pthread_mutex_init(serial_ard6_mutex, &attr)) != 0)
        printf("error %d initializing serial_ard6_mutex\n", rc);
    if ((rc = pthread_mutex_init(socket_mutex, &attr)) != 0)
        printf("error %d initializing socket_mutex\n", rc);
}

thread_return_type Serial_ard1_Thread(void* n)
{
	int rc, i = 0, err;
	int stop = FALSE;

    char buf[255];                      /* message buffer */
    char ch;

    int fd_serial;

    memcpy(&fd_serial,n,sizeof(fd_serial));

	/* loop to receive data from serial */
	while(state)
	{
		stop = FALSE;

		while (!stop)
		{
            err = read(fd_serial, &ch, 1);
            if(err > 0)
			{
				buf[i++] = ch;
				if(ch == '\n' && buf[i-2] == '\r') // look for packet end
				{
					if(i==sizeof(ard_serial_data_packet))
					   stop = TRUE;
					else
					   i = 0;
				}
			}
		}

#ifdef DEBUG_RAW
		for(i = 0; i < sizeof(ard_serial_data_packet); i++)
		{
			printf("%02x ",buf[i]);
		}

		printf("\n");
#endif

		rc = Thread_lock_mutex(serial_ard1_mutex);
		if (rc != 0)
			printf("Error %s locking mutex\n", strerror(rc));

		memcpy(&serial_data,buf,sizeof(ard_serial_data_packet));
        
        //Avg values
        serial_data.health = (uint8_t)xor_func(serial_data.health);
        serial_data.acc[0] = avg_func(serial_data.acc[0], ACCEL_1)*981/16380.0;
        serial_data.acc[1] = avg_func(serial_data.acc[1], ACCEL_2)*981/16380.0;
        serial_data.acc[2] = avg_func(serial_data.acc[2], ACCEL_3)*981/16380.0;
        serial_data.temp[0] = avg_func(serial_data.temp[0], BATT_TEMP1);
        serial_data.temp[1] = avg_func(serial_data.temp[1], BATT_TEMP2);
        serial_data.temp[2] = avg_func(serial_data.temp[2], BATT_TEMP3);
        serial_data.temp[3] = avg_func(serial_data.temp[3], BATT_TEMP4);
        serial_data.temp[4] = avg_func(serial_data.temp[4], BATT_TEMP5);
        serial_data.temp[5] = avg_func(serial_data.temp[5], BATT_TEMP6);
        serial_data.temp[6] = avg_func(serial_data.temp[6], BATT_TEMP7);
        serial_data.temp[7] = avg_func(serial_data.temp[7], BATT_TEMP8);

        main_ready = TRUE;
        socket_ready = TRUE;

		rc = Thread_unlock_mutex(serial_ard1_mutex);
		if (rc != 0)
			printf("Error %s unlocking mutex\n", strerror(rc));
        
        //rc = Thread_signal_cond(serial_cond);
	    //if (rc != 0)
		    //printf("Error %d from signal cond", rc);

        usleep(100);
	}
	exit(0);
}

thread_return_type Socket_Thread(void* n)
{
    char buf[255];
	int rc;
    struct timeval time1_val, time2_val, time3_val, time4_val;
    long mtime, seconds, useconds; 
    int slen=sizeof(remaddr);
    int packet_count = 0;   
    struct sigaction handler;
    ard_serial_data_packet serial_buf;
    int flag = 0;
    
    /* Initialize signal interrupt to receive data from GCS */
    handler.sa_handler = SockRdIntHandler;
    if(sigfillset(&handler.sa_mask) < 0)
        printf("Error sigfillset() failed\n");

    handler.sa_flags = 0;

    if(sigaction(SIGIO, &handler, 0) < 0)
        printf("Error sigaction failed\n");

    if(fcntl(fd_socket, F_SETOWN, getpid()) < 0)
        printf("Error setting signal for the socket\n");

    if(fcntl(fd_socket, F_SETFL, O_NONBLOCK|FASYNC) <0)
        printf("Error setting socket to nonblocking async mode\n");

    /* initial time to receive data from GCS */    
    gettimeofday(&time1_val, NULL);

    while(state)
    {
        if(!socket_wait_flag)
        {
            socket_wait_flag = TRUE;
            Socket_Read();
            gettimeofday(&time1_val, NULL);
        }

        /* Wait for 2.5 sec for receiving data from GCS */
        gettimeofday(&time2_val, NULL);
        seconds  = time2_val.tv_sec  - time1_val.tv_sec;
        useconds = time2_val.tv_usec - time1_val.tv_usec;

        mtime = ((seconds) * 1000 + useconds/1000.0);

        if(mtime > 2500 && packet_count >= 10)
        {
            printf("Lost connection with GCS\n");
            connection_lost = TRUE;
            exit(0);
        }


        rc = Thread_lock_mutex(serial_ard1_mutex);
	    if (rc != 0)
		    printf("Error %s locking mutex\n", strerror(rc));

	/* If arduino serial data is available socket_ready is set to TRUE */
        if(socket_ready)
        {
            buf[0] = 0x02;
            memcpy(&buf[1],&serial_data,sizeof(ard_serial_data_packet));
            //memcpy(&serial_buf,&serial_data,sizeof(ard_serial_data_packet));
        }
        else
        {
            buf[0] = 0x03;
            memset(&buf[1],0xFF,sizeof(ard_serial_data_packet));
        }

        socket_ready = FALSE;

        rc = Thread_unlock_mutex(serial_ard1_mutex);
	    if (rc != 0)
		    printf("Error %s unlocking mutex\n", strerror(rc));


#if 0
        serial_buf.velocity = htons(serial_buf.velocity);
        serial_buf.acc[0] = htons(serial_buf.acc[0]);
        serial_buf.acc[1] = htons(serial_buf.acc[1]);
        serial_buf.acc[2] = htons(serial_buf.acc[2]);
        serial_buf.omega[0] = htons(serial_buf.omega[0]);
        serial_buf.omega[1] = htons(serial_buf.omega[1]);
        serial_buf.omega[2] = htons(serial_buf.omega[2]);
#endif
        /* If there is no serial data from arduino send "RPi Alive" to GCS */
        if(buf[0] == 0x03)
        {
            if(flag == 0)
            {
                gettimeofday(&time3_val, NULL);
                flag = 1;
            }
            gettimeofday(&time4_val, NULL);
            seconds  = time4_val.tv_sec  - time3_val.tv_sec;
            useconds = time4_val.tv_usec - time3_val.tv_usec;

            if(seconds >= 2)
            {
                printf("Sending Rpi alive\n");
                sendto(fd_socket, buf, 2, 0, (struct sockaddr *)&remaddr, slen); 
                flag = 0;
                if(packet_count < 10)
                    packet_count++;
            }
        }else{
            flag = 0;
            printf("Sending packet\n");
            if (sendto(fd_socket, buf, sizeof(ard_serial_data_packet) + 1, 0, (struct sockaddr *)&remaddr, slen)==-1) 
            {
                perror("sendto");
                return 0;
            }
            else
            {
                if(packet_count < 10)
                    packet_count++;
            }
        }
    }
    usleep(1000);
    exit(0);
}


void SockRdIntHandler(int signal)
{
    socket_wait_flag = FALSE;
}

void Socket_Read()
{
    int rc;
    char buf[255];
    //char ack[] = "ack";
    int slen=sizeof(remaddr);
    int recvlen, i = 0, j;             
	int stop;

    /* receive acknowledgement from the server */
    recvlen = recvfrom(fd_socket, buf, 255, MSG_DONTWAIT, (struct sockaddr *)&remaddr, (socklen_t *)&slen);

    stop = FALSE;
    while(!stop && recvlen >= 3)
    {
        buf[recvlen] = 0;	/* expect a printable string - terminate it */

        for(i = 0; i < recvlen; i++)
        {
            if(buf[i] == '\n' && buf[i-1] == '\r') // look for packet end
            {
                stop = TRUE;
                break;
            }      
        }
    } 
#ifdef DEBUG_RAW
	for(j = 0; j < sizeof(socket_data); j++)
	{
		printf("%02x ",buf[j]);
	}

	printf("\n");
#endif
    
    rc = Thread_lock_mutex(socket_mutex);
    if (rc != 0)
        printf("Error %s locking mutex\n", strerror(rc));
    
    memcpy(socket_data,&buf[i-2],sizeof(socket_data));

    rc = Thread_unlock_mutex(socket_mutex);
    if (rc != 0)
        printf("Error %s unlocking mutex\n", strerror(rc));
    
    switch(buf[i-2])
    {
        case 1:
            rc = write(fd_ard6_serial,&buf[i-2],1);               
            if(rc <= 0)
                perror("write error\n");
        break;
        default:
        break;
    }
}

/* Function used to convert constant server ip address t0 variable */
char* Strdup(const char* src)
{
    size_t mlen = strlen(src) + 1;
	char* temp = malloc(mlen);
	strncpy(temp, src, mlen);
	return temp;
}

int xor_func(int M)
{
    static unsigned int LM[5] = {0};
    static uint8_t index = 0;
    static uint8_t sum[5] = {0};
    static unsigned int xor_m = 0;
    uint8_t i = 0;
#if 0
    for(i = 0; i < 5; i++)
    {
        sum[i] -= (LM[index] & (0x01 << i));
        LM[index] = M;
        sum[i] += (LM[index] & (0x01 << i));

        if(sum[i]*10/5 > 5)
            xor_m |= (0x01 << i);
        else
            xor_m &= ~(0x01 << i);
    }
#else
    xor_m ^= LM[index];
    LM[index] = M;
    xor_m ^= LM[index];
#endif
    index++;
    index %= 5;

    return xor_m;
}

int16_t avg_func(int16_t value, avg_values member)
{
    static unsigned int LM[MAX_AVG][5] = {{0}};
    static uint8_t index[MAX_AVG] = {0};
    static long sum[MAX_AVG] = {0};
    static uint8_t count[MAX_AVG] = {0};
    unsigned int avg_value = 0;

    sum[member] -= LM[member][index[member]];
    LM[member][index[member]] = value;
    sum[member] += LM[member][index[member]];
    index[member]++;
    index[member] %= 5;

    if(count[member] < 5) count[member]++;

    avg_value = sum[member] / count[member];

    return avg_value;
}
