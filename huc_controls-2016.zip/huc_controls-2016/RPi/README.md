Hyperloop Team Network Guide:
Overview:
1.We need to develop a UDP client application in linux for RPI to communicate with SpaceX server.
2.Client application is nothing but a socket program.
	For information on socket programming visit: https://www.freebsd.org/doc/en_US.ISO8859-1/books/developers-handbook/sockets-essential-functions.html
	https://www.cs.rutgers.edu/~pxk/417/notes/sockets/udp.html

