// @brief Contains macros for client and server ip
// @author 
// Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
// thereof is to be copied, reproduced or communicated to any person without
// written permission.

#ifndef _NETWORK_H
#define _NETWORK_H

//#define CLIENT_ADDR "192.168.1.12"
//#define SERVER_ADDR "192.168.1.21"
#define CLIENT_ADDR "192.168.1.2"
#define SERVER_ADDR "192.168.1.4"
#define PORT 3000

#endif
