// @brief header code for RPi
// @author 
// Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
// thereof is to be copied, reproduced or communicated to any person without
// written permission.

#ifndef _MAIN_H
#define _MAIN_H

#include "gpio_macros.h"
#include "network.h"
#include "datapacket.h"
#include "Thread.h"

#define DEBUG /* Used to for debug prints, comment if prints are not required */
#define DEBUG_RAW

char* Strdup(const char*); /* Function used to convert constant server ip address t0 variable */
int GPIO_init(void); /* GPIO initialization */
int Socket_init(int); /* Socket initialization */
void Serial_init(int); /* Serial initialization */
void Thread_init(); /* Initialize threads, mutex and semaphores */
thread_return_type Serial_ard1_Thread(void*); /* Serial Read Thread Function */
thread_return_type Serial_ard6_Thread(void*); /* Serial Read Thread Function */
thread_return_type Socket_Thread(void*); /* Socket send/receive Thread Function */
void SockRdIntHandler(int); /* Socket read interrupt handler */
void Socket_Read(void);
int xor_func(int); /* xor function used to average health */
int16_t avg_func(int16_t ,avg_values );

#endif
