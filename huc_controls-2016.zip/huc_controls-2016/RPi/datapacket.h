// @brief Contains data structures of aruduino2-5 data packet, arduino serial data packet and SpaceX pod data packet
// @author 
// Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
// thereof is to be copied, reproduced or communicated to any person without
// written permission.

#ifndef _DATA_PACKET_H
#define _DATA_PACKET_H

#include <stdint.h>

#define INT8 	int8_t
#define UINT8 	uint8_t
#define INT16 	int16_t
#define UINT16	uint16_t
#define INT32 	int32_t
#define UINT32 	uint32_t

typedef enum 
{
    //VELOCITY,
    ACCEL_1,
    ACCEL_2,
    ACCEL_3,
#if 0
    ATTIT_1,
    ATTIT_2,
    ATTIT_3,
    ATTIT_4,
    OMEGA_1,
    OMEGA_2,
    OMEGA_3,
#endif
    BATT_TEMP1,
    BATT_TEMP2,
    BATT_TEMP3,
    BATT_TEMP4,
    BATT_TEMP5,
    BATT_TEMP6,
    BATT_TEMP7,
    BATT_TEMP8,
    MAX_AVG
} avg_values; 

typedef enum
{
    FAULT,
    IDLE,
    READY,
    PUSHING,
    COAST,
    BRAKING
}spacex_status;

#pragma pack(1)
typedef struct
{
 	UINT8   health;      /*Health of all Arduinos*/
	UINT8   stripe;      /*Stripe Count*/
	UINT16  velocity;    /*Velocity*/
    UINT8   mag_brake;
    UINT8   fric_brake;
    UINT8   ard3_act_dist[4]; /*Ard3 actuator distance*/
    UINT8   ard4_act_dist[4]; /*Ard4 actuator distance*/
	INT16   acc[3];     /*Accel readings*/
  	INT16   omega[3];   /*Gyro*/
  	UINT8   dist[8];   /*Distance*/
    INT16   temp[8];
    UINT8   voltage[8];
  	UINT8   CR;
  	UINT8   LF;
} ard_serial_data_packet;
#pragma pack()


#if 0
#pragma pack(1)
typedef struct
{
 	UINT8 health;      /*Health of all Arduinos*/
	UINT16 acc[3];     /*Accel readings*/
  	UINT16  omega[3];   /*Gyro*/
  	UINT8 CR;
  	UINT8 LF;
} ard_serial_data_packet;
#pragma pack()

#define ard_serial_data_packet_initializer {0xAA, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0D, 0x0A}
#endif

#pragma pack(1)
typedef struct
{
 	UINT8 ultrasonic;      /*ultrasonic data*/
	//UINT16 strain_guage[4];     /*Strain Gauge*/
  	UINT8 CR;
  	UINT8 LF;
} ard6_serial_data_packet;
#pragma pack()

//#define ard6_serial_data_packet_initializer {0x00, 0x0000, 0x0000, 0x0000, 0x0000, 0x0D, 0x0A}
#define ard6_serial_data_packet_initializer {0x00, 0x0D, 0x0A}

typedef struct
{
	/* Identifier for the team, assigned by SpaceX. Required. */
	UINT8 team_id;
	/* Pod status, indicating current pod health and pushing state, as defined below. Required. */
	UINT8 status;
	/* Acceleration in centimeters per second squared. Required. */
	INT32 acceleration;
	/* Position in centimeters.Required. */
	INT32 position;
	/* Velocity in centimeters per second. Required. */
	INT32 velocity;
	/* Battery voltage in millivolts. */
	INT32 battery_voltage;
	/* Battery current in milliamps. */
	INT32 battery_current;
	/* Battery temperature in tenths of a degree Celsius. */
	INT32 battery_temperature;
	/* Pod temperature in tenths of a degree Celsius. */
	INT32 pod_temperature;
	/* Count of optical navigation stripes detected in the tube. */
	UINT32 stipe_count;
} pod_monitor;

#define pod_monitor_initializer { 12, 1, 40, 150, 300, 1000, 500, 250, 300, 10}

#endif
