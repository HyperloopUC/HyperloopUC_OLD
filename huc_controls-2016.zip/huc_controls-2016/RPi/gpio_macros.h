// @brief Contains macros for RPI 3 GPIO map
// @author 
// Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
// thereof is to be copied, reproduced or communicated to any person without
// written permission.

#ifndef _GPIO_MACRO_H
#define _GPIO_MACRO_H

#define WIRING_PI_MAP 

#ifdef WIRING_PI_MAP
/* GPIO pins macros for wiring pi */
#define GPIO02	
#define GPIO03	
#define GPIO04	4
#define GPIO05	5	
#define GPIO06	6
#define GPIO07	
#define GPIO08	
#define GPIO09	
#define GPIO10	
#define GPIO11	
#define GPIO12	12
#define GPIO13	13
#define GPIO14	
#define GPIO15	
#define GPIO16	16
#define GPIO17	17
#define GPIO18	18
#define GPIO19	19
#define GPIO20	20
#define GPIO21	21
#define GPIO22	22
#define GPIO23	23
#define GPIO24	24
#define GPIO25	25	
#define GPIO26	26
#define GPIO27	27
#define ID_SD	
#define ID_SC	
#else
/* GPIO pins macros for BCM */
#define GPIO02	8
#define GPIO03	9
#define GPIO04	7
#define GPIO05	21	
#define GPIO06	22
#define GPIO07	11
#define GPIO08	10
#define GPIO09	13
#define GPIO10	12
#define GPIO11	14 /*not working*/
#define GPIO12	26
#define GPIO13	23
#define GPIO14	15
#define GPIO15	16
#define GPIO16	27
#define GPIO17	0
#define GPIO18	1
#define GPIO19	24
#define GPIO20	28
#define GPIO21	29
#define GPIO22	3
#define GPIO23	4
#define GPIO24	5
#define GPIO25	6	
#define GPIO26	25
#define GPIO27	2
#define ID_SD	30
#define ID_SC	31
#endif

/* Multiplexed pins for GPIO */
#define SDA1 		GPIO02
#define SCL1		GPIO03
#define GPIO_GCLK	GPIO04
#define SPI_CE1_N	GPIO07
#define SPI_CE0_N	GPIO08
#define SPI_MISO	GPIO09
#define SPI_MOSI	GPIO10
#define SPI_CLK		GPIO11
#define TXD0		GPIO14
#define RXD0		GPIO15
#define GPIO_GEN0	GPIO17
#define GPIO_GEN1	GPIO18
#define GPIO_GEN2	GPIO27
#define GPIO_GEN3	GPIO22
#define GPIO_GEN4	GPIO23
#define GPIO_GEN5	GPIO24
#define GPIO_GEN6	GPIO25

#endif
