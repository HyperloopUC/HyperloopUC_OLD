basic2-3-4-5_tx_code
this file shows the integration of the basic functionality of the Arduino 2,3,4,5 which will be sending data to Arduino 1.

1 >>>>>
Watchdog
this code has a digital pin 2 dedicated to watchdog interrupt which basically receives a "ping" (high to low signal) from RPi.
the interrupt is activated when a falling signal is detected
this signifies that the RPi is alive.
currently timed for around 2.5 sec.
if RPi fails to give its status at least once in 2.5 sec, Ard2-3-4-5 will changes their functionality as defined.

2 >>>>>
Timer
this code is facilitated with a timer-counter number 3
currently timed for 0.5 sec
it sends data over CAN every 0.5 sec

3 >>>>>
CAN-send
the code here is a CAN send code
refer(CAN Library)




*****
As ADC is widely being used in our application, it will be added to this code later things to be added in future
