% @brief This script is to plot pitch, roll and yaw obtained from the four test setup of hover engines
% @author 
% Subject to the existing rights of third parties, HYPERLOOP UC is the owner of the copyright in this work and no portion
% thereof is to be copied, reproduced or communicated to any person without
% written permission.

clc
clear all
close all

%Reading data and initalizing parameters
testdata = xlsread('FourEngineTestData.xlsx');

height1 = testdata(:,1);
height2 = testdata(:,2);
height3 = testdata(:,3);
height4 = testdata(:,4);
r = testdata(:,5);
r(0) = 0;
i = 1;
dt = 0.1;
time = (0.1:dt:size(testdata,1)*dt)';

podlength = ;
podwidth = ;

% Pitch
theta = (((height1 - height4)/podlength) + ((height2 - height3)/podlength))/2;

% Roll
phi = (((height1 - height2)/podwidth) +((height4 - height3)/podwidth))/2;

% Yaw
for i = 1:size(testdata,5)
psi(i) = r(i) + r(i-1)*dt;
end

figure(1)
plot(dt,theta)
xlabel('Time (s)')
ylabel('Pitch (deg)')
title('Pitch vs Time')

figure(2)
plot(dt,phi)
xlabel('Time (s)')
ylabel('Roll (deg)')
title('Roll vs Time')


figure(3)
plot(dt,psi)
xlabel('Time (s)')
ylabel('Yaw (deg)')
title('Yaw vs Time')