# Setting up of Navio on Rpi

Note: In order to use Navio2 on Rpi3 you need to download the SD card image provided my emlid.

## Burning SD card image:
Steps to write rpi image into SD card:
* Get the latest Emlid Raspbian Image. (Available from [emlid configure rpi]( https://docs.emlid.com/navio2/Navio-APM/configuring-raspberry-pi/))
* Download, extract and run Etcher with administrator rights. (Available from [etcher]( https://etcher.io/))
* Select the archive file with image and sd card drive letter. 
* Click “Flash!”. The process may take a few minutes.

## Configuring Wi-Fi access:
* Wi-Fi networks can be configured by editing the /boot/wpa_supplicant.conf file located on SD card. To add your network simply add the following lines to it:

```javascript
  network={
    ssid="yourssid"
    psk="yourpasskey"
    key_mgmt=WPA-PSK
  }
```

### To get access to this file use one of the following methods:
#### Edit configuration on SD card
* Simply plug an SD card in your computer. After getting access to SD card contents, open /boot/wpa_supplicant.conf (with root privileges on Linux) 
    and edit the file as described above.
#### Use monitor and keyboard
* Connect HDMI monitor and USB keyboard to your Raspberry, power it up and you will get access to the console, where you can use text editor to modify wpa_supplicant. After logging into the system, type:
```javascript
	sudo nano /boot/wpa_supplicant.conf
 ```
* Modify the file as described above, save it and reboot. This method may be problematic because some keyboards are not compatible with this kernel. If your keyboard does not work, try another one or use another method.

* If required you can now upgrade your system by running:
```javascript
	sudo apt-get update && sudo apt-get dist-upgrade
```
## Downloading drivers and examples for Navio2
* Clone our repository to get access to Navio2 examples:
```javascript
  git clone https://github.com/emlid/Navio2.git
  cd Navio2
```
### IMU: MPU9250 and LSM9DS1
* Navio2 contains two 9DOF (degree of freedom) IMU - MPU9250 and LSM9DS1. Each of them combines a gyroscope, an accelerometer and a magnetometer in one device. IMU sensors are not only popular as a part of drone autopilot projects, but are also widely used in devices like cellphones, tablets, etc.
* IMU example for Navio2 runs with one of the on-board sensors at a time. During start-up program you have to specify with which sensor to work.
* To compile and run the code follow the steps given below:
```javascript
  cd C++/Examples/AccelGyroMag
  make
  ./AccelGyroMag -i mpu 
```
You should immediately see 9 values, updated in real time. Try to move the device around and see them change. They include Accelerometer, Gyroscope and Magnetometer data, three axis each.
```javascript
    Selected: MPU9250
    Connection established:  True
    Acc:  +0.014  +0.139  +9.974  Gyr:   -0.042   +0.022   +0.011  Mag: -3525.450 +29.584  +0.000
    Acc:  -0.010  +0.268 +10.036  Gyr:   -0.042   +0.019   +0.015  Mag: -14.963 +43.390 -50.130
    Acc:  -0.010  +0.278  +9.888  Gyr:   -0.043   +0.021   +0.012  Mag: -16.566 +42.852 -50.302
    Acc:  +0.010  +0.187 +10.041  Gyr:   -0.039   +0.021   +0.011  Mag: -14.963 +42.314 -50.817
    Acc:  -0.062  +0.158  +9.855  Gyr:   -0.039   +0.020   +0.011  Mag: -15.497 +42.493 -49.959
    Acc:  -0.067  +0.196 +10.056  Gyr:   -0.044   +0.020   +0.013  Mag: -14.963 +43.748 -50.130
```
* Use lsm instead of mpu for LSM9DS1 readings.