void loop() {

int count = 0;
int countCrt = 0;
boolean sensorVal1 = 0;
boolean sensorVal2 = 0;
boolean sensorVal3 = 0;
boolean sensorVal4 = 0;
boolean sensorVal5 = 0;
boolean sensorVal6 = 0;
boolean newContrastArrayVal1 = 0; 
boolean newContrastArrayVal2 = 0; 
boolean oldContrastArrayVal1 = 0;
boolean oldContrastArrayVal2 = 0;
boolean flag1; // if sensor at head of pod detects a strip
boolean flag2; // if sensor at tail of pod detects a strip
boolean flagCrt; // if both flag500 and flag1000 are true
boolean flag500; // when sensor at head of pod detects the 5 strip bundle (500 ft left)
boolean flag1000; // when sensor at head of pod detects the 10 strip bundle (1000 ft left)
unsigned long int timer0 = 0;
unsigned long int timer1 = 0;
unsigned long int timer2 = 0;
int velocity = 0;
double radius = 0.29;

	while (1) {
		// Gathering inputs needs to be done in every loop to determine the state 
		sensorVal1 = getContrastSensorData(6);
      	sensorVal2 = getContrastSensorData(7);
      	sensorVal3 = getContrastSensorData(8);
      	newContrastArrayVal1 = ((sensorVal1 && sensorVal2) || (sensorVal2 && sensorVal3) || (sensorVal3 && sensorVal1));
      	sensorVal4 = getContrastSensorData(9);
      	sensorVal5 = getContrastSensorData(10);
      	sensorVal6 = getContrastSensorData(11);
     	newContrastArrayVal2 = ((sensorVal4 && sensorVal5) || (sensorVal5 && sensorVal6) || (sensorVal6 && sensorVal4));

		if before detecting any strips or in the middle of strip
			keep moving;
		else if head sensor detected a strip
			// we don't know yet if this is a bundle of strips or just one single strip, so let's wait
			// we can have a count varible to count the number of strips the head sensor crosses through without being interrupted by tail sensor

			if (count == 0) count++;
			else // if the head sensor just passed one strip and then another without beingn interrupted by tail sensor, we have bundle now
				if the bundle is 10 strips
					do something
				else if the bundle is 5 strips
					do some other things
		else if tail sensor detected a strip
			if flagCrt is true
				we are in bundle region
			else 
				we are just passing through a single strip
	}
}
