**************************************************

Hyperloop UC 2015

Braking

**************************************************

CONTENT

(code)
1)Contrast Sensor
2)Velocity derivation
3)Braking optization (matlab) 
4)Magnetic Actuator
5)Friction Actuator


(datasheet)
1)Contrast Sensor
2)Magnetic Actuator
3)Friction Actuator


**************************************************
