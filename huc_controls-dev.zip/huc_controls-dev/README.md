# huc_controls
All the controls and electronics algorithms for HUC
